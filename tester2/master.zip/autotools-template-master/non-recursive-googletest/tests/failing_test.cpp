#include "foo.hpp"
#include "mygtest.hpp"

TEST(ColorTests, HandlesFoo) {
    EXPECT_EQ(1, 1);
}



