#include <iostream>
#include "foo.hpp"

using namespace std;

int main()
{
    foo();
    cout << "passing_test is running" << endl;
    // Return of 0 means the test passed.
}
