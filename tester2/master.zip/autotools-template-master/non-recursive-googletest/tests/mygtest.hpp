/* A simple wrapper to suppress all warnings from gtest.h */
#pragma GCC system_header
#include "gtest/gtest.h"
