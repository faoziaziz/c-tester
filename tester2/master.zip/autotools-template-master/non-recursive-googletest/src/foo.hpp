#ifndef FOO_HPP
#define FOO_HPP

#include <iostream>

inline void foo()
{
    std::cout << "fooing" << std::endl;
}

#endif
