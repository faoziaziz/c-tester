/* A simple wrapper to suppress all warnings from catch.hpp */
#pragma GCC system_header
#include "catch.hpp"

