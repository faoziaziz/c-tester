Mantrap
=============================

boilerplate for small C programs with autotools

Installation
------------

Execute the following commands:

    $ ./configure
    $ make
    $ sudo make install

# TODO:6000 Update the README.md file with a complete description
# TODO:6000 and some usage instructions.
